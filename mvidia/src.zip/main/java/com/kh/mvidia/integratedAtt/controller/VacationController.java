package com.kh.mvidia.integratedAtt.controller;

public class VacationController {
}
